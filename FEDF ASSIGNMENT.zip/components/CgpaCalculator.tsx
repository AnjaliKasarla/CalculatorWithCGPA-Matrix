
import React, { useState, useMemo } from 'react';
import { Course } from '../types';

const CgpaCalculator: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([{ id: 1, credits: '', grade: '' }]);
  const [nextId, setNextId] = useState(2);

  const handleAddCourse = () => {
    setCourses([...courses, { id: nextId, credits: '', grade: '' }]);
    setNextId(nextId + 1);
  };

  const handleRemoveCourse = (id: number) => {
    setCourses(courses.filter(course => course.id !== id));
  };

  const handleCourseChange = (id: number, field: 'credits' | 'grade', value: string) => {
    setCourses(courses.map(course => 
      course.id === id ? { ...course, [field]: value } : course
    ));
  };

  const cgpa = useMemo(() => {
    let totalCredits = 0;
    let totalGradePoints = 0;

    courses.forEach(course => {
      const credits = parseFloat(course.credits);
      const grade = parseFloat(course.grade);

      if (!isNaN(credits) && !isNaN(grade) && credits > 0) {
        totalCredits += credits;
        totalGradePoints += credits * grade;
      }
    });

    if (totalCredits === 0) return 0;
    return totalGradePoints / totalCredits;
  }, [courses]);

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col items-center">
      <div className="w-full p-4 bg-gray-900 rounded-lg shadow-lg">
        <div className="mb-6 text-center">
          <h2 className="text-2xl font-bold text-cyan-400">CGPA: {cgpa.toFixed(2)}</h2>
        </div>
        
        <div className="space-y-4 mb-4">
          {courses.map((course, index) => (
            <div key={course.id} className="grid grid-cols-12 gap-2 items-center animate-fade-in">
              <span className="col-span-1 text-gray-400 font-semibold">{index + 1}.</span>
              <div className="col-span-5">
                <input
                  type="number"
                  placeholder="Credits"
                  value={course.credits}
                  onChange={(e) => handleCourseChange(course.id, 'credits', e.target.value)}
                  className="w-full p-2 bg-gray-700 rounded border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"
                />
              </div>
              <div className="col-span-5">
                <input
                  type="number"
                  placeholder="Grade Points"
                  value={course.grade}
                  onChange={(e) => handleCourseChange(course.id, 'grade', e.target.value)}
                  className="w-full p-2 bg-gray-700 rounded border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500 transition"
                />
              </div>
              <div className="col-span-1 flex justify-end">
                <button
                  onClick={() => handleRemoveCourse(course.id)}
                  className="p-2 text-red-500 hover:text-red-400 rounded-full hover:bg-red-500/10 transition"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M9 2a1 1 0 00-.894.553L7.382 4H4a1 1 0 000 2v10a2 2 0 002 2h8a2 2 0 002-2V6a1 1 0 100-2h-3.382l-.724-1.447A1 1 0 0011 2H9zM7 8a1 1 0 012 0v6a1 1 0 11-2 0V8zm4 0a1 1 0 012 0v6a1 1 0 11-2 0V8z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
            </div>
          ))}
        </div>
        
        <button
          onClick={handleAddCourse}
          className="w-full py-2 px-4 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded-lg transition-transform transform hover:scale-105"
        >
          Add Course
        </button>
      </div>
    </div>
  );
};

export default CgpaCalculator;
