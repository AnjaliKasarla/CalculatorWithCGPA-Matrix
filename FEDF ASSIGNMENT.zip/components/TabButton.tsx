
import React from 'react';

interface TabButtonProps {
  label: string;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ label, isActive, onClick }) => {
  const activeClasses = 'bg-cyan-500 text-white';
  const inactiveClasses = 'bg-transparent text-gray-300 hover:bg-gray-700';

  return (
    <button
      onClick={onClick}
      className={`flex-1 py-3 px-2 text-sm sm:text-base font-semibold transition-colors duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-cyan-400 focus:ring-opacity-50 ${isActive ? activeClasses : inactiveClasses}`}
    >
      {label}
    </button>
  );
};

export default TabButton;
