
import React, { useState, useCallback } from 'react';
import { Matrix } from '../types';

const MatrixInput: React.FC<{
  matrix: Matrix;
  onMatrixChange: (matrix: Matrix) => void;
  rows: number;
  cols: number;
}> = ({ matrix, onMatrixChange, rows, cols }) => {
    
  const handleCellChange = (rowIndex: number, colIndex: number, value: string) => {
    const newMatrix = matrix.map(row => [...row]);
    newMatrix[rowIndex][colIndex] = parseFloat(value) || 0;
    onMatrixChange(newMatrix);
  };

  return (
    <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
      {Array.from({ length: rows }).map((_, r) =>
        Array.from({ length: cols }).map((_, c) => (
          <input
            key={`${r}-${c}`}
            type="number"
            value={matrix[r]?.[c] ?? ''}
            onChange={(e) => handleCellChange(r, c, e.target.value)}
            className="w-full text-center p-2 bg-gray-700 rounded border border-gray-600 focus:outline-none focus:ring-2 focus:ring-cyan-500"
          />
        ))
      )}
    </div>
  );
};


const MatrixCalculator: React.FC = () => {
  const [rowsA, setRowsA] = useState(2);
  const [colsA, setColsA] = useState(2);
  const [rowsB, setRowsB] = useState(2);
  const [colsB, setColsB] = useState(2);

  const createMatrix = (rows: number, cols: number): Matrix => Array(rows).fill(0).map(() => Array(cols).fill(0));

  const [matrixA, setMatrixA] = useState<Matrix>(createMatrix(2, 2));
  const [matrixB, setMatrixB] = useState<Matrix>(createMatrix(2, 2));
  const [resultMatrix, setResultMatrix] = useState<Matrix | null>(null);
  const [error, setError] = useState<string>('');

  const updateMatrixA = useCallback((r: number, c: number) => {
    setRowsA(r);
    setColsA(c);
    setMatrixA(createMatrix(r, c));
  }, []);
  
  const updateMatrixB = useCallback((r: number, c: number) => {
    setRowsB(r);
    setColsB(c);
    setMatrixB(createMatrix(r, c));
  }, []);

  const handleOperation = (op: 'add' | 'subtract' | 'multiply') => {
    setError('');
    setResultMatrix(null);
    if (op === 'add' || op === 'subtract') {
      if (rowsA !== rowsB || colsA !== colsB) {
        setError('Matrices must have the same dimensions for addition/subtraction.');
        return;
      }
      const result = createMatrix(rowsA, colsA);
      for (let i = 0; i < rowsA; i++) {
        for (let j = 0; j < colsA; j++) {
          result[i][j] = op === 'add' ? matrixA[i][j] + matrixB[i][j] : matrixA[i][j] - matrixB[i][j];
        }
      }
      setResultMatrix(result);
    } else if (op === 'multiply') {
      if (colsA !== rowsB) {
        setError('Columns of Matrix A must equal rows of Matrix B for multiplication.');
        return;
      }
      const result = createMatrix(rowsA, colsB);
      for (let i = 0; i < rowsA; i++) {
        for (let j = 0; j < colsB; j++) {
          let sum = 0;
          for (let k = 0; k < colsA; k++) {
            sum += matrixA[i][k] * matrixB[k][j];
          }
          result[i][j] = sum;
        }
      }
      setResultMatrix(result);
    }
  };
  
  const DimensionControl: React.FC<{label: string, rows: number, cols: number, onUpdate: (r: number, c: number) => void}> = ({label, rows, cols, onUpdate}) => (
     <div className="flex items-center gap-2">
        <label className="font-semibold">{label}:</label>
        <input type="number" value={rows} min="1" max="8" onChange={(e) => onUpdate(parseInt(e.target.value), cols)} className="w-16 p-1 bg-gray-700 rounded border border-gray-600" />
        <span className="text-gray-400">x</span>
        <input type="number" value={cols} min="1" max="8" onChange={(e) => onUpdate(rows, parseInt(e.target.value))} className="w-16 p-1 bg-gray-700 rounded border border-gray-600" />
      </div>
  )

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <DimensionControl label="Matrix A" rows={rowsA} cols={colsA} onUpdate={updateMatrixA} />
          <DimensionControl label="Matrix B" rows={rowsB} cols={colsB} onUpdate={updateMatrixB} />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        <div>
          <h3 className="text-lg font-bold mb-2 text-cyan-400">Matrix A</h3>
          <MatrixInput matrix={matrixA} onMatrixChange={setMatrixA} rows={rowsA} cols={colsA} />
        </div>
        <div>
          <h3 className="text-lg font-bold mb-2 text-cyan-400">Matrix B</h3>
          <MatrixInput matrix={matrixB} onMatrixChange={setMatrixB} rows={rowsB} cols={colsB} />
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-4 my-4">
        <button onClick={() => handleOperation('add')} className="px-4 py-2 bg-cyan-600 rounded hover:bg-cyan-500 transition">Add (A + B)</button>
        <button onClick={() => handleOperation('subtract')} className="px-4 py-2 bg-cyan-600 rounded hover:bg-cyan-500 transition">Subtract (A - B)</button>
        <button onClick={() => handleOperation('multiply')} className="px-4 py-2 bg-cyan-600 rounded hover:bg-cyan-500 transition">Multiply (A * B)</button>
      </div>
      
      {error && <div className="text-center p-3 bg-red-500/20 text-red-400 rounded-lg">{error}</div>}

      {resultMatrix && (
        <div>
          <h3 className="text-xl font-bold text-center mb-4 text-cyan-400">Result</h3>
          <div className="p-4 bg-gray-900 rounded-lg flex justify-center">
            <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${resultMatrix[0].length}, minmax(0, 1fr))` }}>
              {resultMatrix.map((row, r) =>
                row.map((cell, c) => (
                  <div key={`${r}-${c}`} className="w-16 h-12 flex items-center justify-center bg-gray-700 rounded font-mono">
                    {cell}
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MatrixCalculator;
