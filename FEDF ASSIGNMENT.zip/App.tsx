
import React, { useState } from 'react';
import { ActiveTool } from './types';
import Calculator from './components/Calculator';
import CgpaCalculator from './components/CgpaCalculator';
import MatrixCalculator from './components/MatrixCalculator';
import TabButton from './components/TabButton';

const App: React.FC = () => {
  const [activeTool, setActiveTool] = useState<ActiveTool>(ActiveTool.Calculator);

  const renderTool = () => {
    switch (activeTool) {
      case ActiveTool.Calculator:
        return <Calculator />;
      case ActiveTool.CgpaCalculator:
        return <CgpaCalculator />;
      case ActiveTool.MatrixCalculator:
        return <MatrixCalculator />;
      default:
        return <Calculator />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 flex flex-col items-center p-4 font-sans">
      <header className="w-full max-w-4xl text-center mb-6">
        <h1 className="text-4xl md:text-5xl font-bold text-cyan-400">Multi-Tool Calculator</h1>
        <p className="text-gray-400 mt-2">Your one-stop solution for various calculations.</p>
      </header>

      <div className="w-full max-w-4xl bg-gray-800 rounded-lg shadow-2xl overflow-hidden">
        <nav className="flex bg-gray-700/50">
          {Object.values(ActiveTool).map((tool) => (
            <TabButton
              key={tool}
              label={tool}
              isActive={activeTool === tool}
              onClick={() => setActiveTool(tool)}
            />
          ))}
        </nav>
        <main className="p-4 sm:p-6 md:p-8">
          {renderTool()}
        </main>
      </div>

      <footer className="mt-8 text-gray-500 text-sm">
        <p>Built with React, TypeScript, and Tailwind CSS</p>
      </footer>
    </div>
  );
};

export default App;
