
export interface Course {
  id: number;
  credits: string;
  grade: string;
}

export type Matrix = number[][];

export enum ActiveTool {
  Calculator = 'Calculator',
  CgpaCalculator = 'CGPA Calculator',
  MatrixCalculator = 'Matrix Calculator',
}
